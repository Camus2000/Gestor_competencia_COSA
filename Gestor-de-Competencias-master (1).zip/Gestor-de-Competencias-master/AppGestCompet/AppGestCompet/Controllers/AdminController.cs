﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AppGestCompet.Models;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace AppGestCompet.Controllers
{
    public class AdminController : Controller
    {

        //Admin
        public ActionResult Admin_mensajeria()
        {
            return View();
        }
        public ActionResult Admin_Perfil()
        {
            return View();
        }
        public ActionResult Admin_Configuracion()
        {
            return View();
        }

        //---------------------------------------------------------------
        public ActionResult Registrar_Profesores()
        {
            return View();
        }
        public ActionResult Registrar_Cursos()
        {
            return View();
        }

        public ActionResult Registrar_Capacidades()
        {
            return View();
        }
        public ActionResult Editar_Profesores()
        {
            return View();
        }
        public ActionResult Editar_Cursos()
        {
            return View();
        }
        public ActionResult Editar_Alumnos()
        {
            return View();
        }
        public ActionResult Editar_Competencias()
        {
            return View();
        }
        public ActionResult Editar_Capacidades()
        {
            return View();
        }

        //---------------------------------------------------------
        public ActionResult Listar_Profesores()
        {
            return View();
        }
        public ActionResult Listar_Cursos()
        {
            return View();
        }
        public ActionResult Listar_Alumnos()
        {
            return View();
        }
        public ActionResult Listar_Competencias()
        {
            return View();
        }
        public ActionResult Listar_Capacidades()
        {
            return View();
        }
        public ActionResult Informes()
        {
            return View();
        }
        
        //---------------------------------
        [HttpGet]
        public ActionResult Registrar_Alumnos()
        {
            string constr = ConfigurationManager.ConnectionStrings["conexion"].ToString();
            SqlConnection _con = new SqlConnection(constr);
            SqlDataAdapter _da = new SqlDataAdapter("select * from Seccion", constr);
            DataTable _dt = new DataTable();
            _da.Fill(_dt);
            ViewBag.ListaSeccion = ToSelectList(_dt, "ID_Seccion", "descripcion");

            return View();
        }
        [HttpPost]
        public ActionResult Registrar_Alumnos(SeccionModel _member)
        {
            return View();
        }

        [NonAction]
        public SelectList ToSelectList(DataTable table, string valueField, string textField)
        {
            List<SelectListItem> list = new List<SelectListItem>();

            foreach (DataRow row in table.Rows)
            {
                list.Add(new SelectListItem()
                {
                    Text = row[textField].ToString(),
                    Value = row[valueField].ToString()
                });
            }

            return new SelectList(list, "Value", "Text");
        }

        //-----------------
        [HttpGet]
        public ActionResult ListaCapacidades()
        {
            string constr = ConfigurationManager.ConnectionStrings["conexion"].ToString();
            SqlConnection _con = new SqlConnection(constr);
            SqlDataAdapter _da = new SqlDataAdapter("select * from Capacidades", constr);
            DataTable _dt = new DataTable();
            _da.Fill(_dt);
            ViewBag.cosa = ToSelectList(_dt, "ID_capacidades", "Nombre");

            return View();
        }
        [HttpPost]
        public ActionResult ListaCapacidades(CapacidadesModel _member)
        {
            return View();
        }


        //-----------------
        [HttpGet]
        public ActionResult Registrar_Competencias()
        {
            string constr = ConfigurationManager.ConnectionStrings["conexion"].ToString();
            SqlConnection _con = new SqlConnection(constr);
            SqlDataAdapter _da = new SqlDataAdapter("select * from Capacidades", constr);
            DataTable _dt = new DataTable();
            _da.Fill(_dt);
            ViewBag.capacidades = ToSelectList(_dt, "ID_capacidades", "Nombre");

            return View();
        }
        [HttpPost]
        public ActionResult Registrar_Competencias(CapacidadesModel _member)
        {
            return View();
        }
    }   
}

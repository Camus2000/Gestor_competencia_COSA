﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AppGestCompet.Models
{
    public class CapacidadesModel
    {
        public int ID_capacidades { get; set; }
        public char Nombre { get; set; }
        public char Descripcion { get; set; }
        public char Desempeños { get; set; }
        public int ID_competencias { get; set; }
        public int ID_curso { get; set; }
    }
}
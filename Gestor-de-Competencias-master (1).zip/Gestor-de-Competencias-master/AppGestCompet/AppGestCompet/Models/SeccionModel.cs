﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AppGestCompet.Models
{
    public class SeccionModel
    {
        public int ID_Seccion { get; set; }
        public char descripcion { get; set; }
}
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AppGestCompet.Models
{
    public class CursoModel
    {
        int  ID_curso  { get; set; }
        string Nombre_curso { get; set; }
        string Descripcion { get; set; }
    }
    public class PeriodoModel
    {
        int ID_Periodo { get; set; }
        char periodo { get; set; }
    }
    public class AlumnoModel
    {
        int ID_alumno  { get; set; }
        string Nombre_alumno { get; set; }
        string Apellido_alumno { get; set; }
        string Seccion  { get; set; }

    }
    public class CompetenciasModel
    {
        int ID_competencias { get; set; }
        string Nombre_competencias { get; set; }
        string Descripcion { get; set; }

    }
}
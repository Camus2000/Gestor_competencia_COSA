﻿using AppGestCompet.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Windows.Documents;

namespace AppGestCompet.ViewModels
{
    public class CalCompViewModel
    {
        public class ListCursoViewModel
        {
            public List<CursoModel> Cursos { get; set; }
            public List<PeriodoModel> Periodos { get; set; }
            public List<AlumnoModel> Alumnos { get; set; }
            public List<CompetenciasModel> Competencias { get; set; }
        }
    }
}
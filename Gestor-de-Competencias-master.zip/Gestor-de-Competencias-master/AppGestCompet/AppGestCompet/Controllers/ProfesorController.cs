﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AppGestCompet.Models;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace AppGestCompet.Controllers
{
    public class ProfesorController : Controller
    {
        //public ActionResult Index()
        //{
        //    return View();
        //}
        //--------- no hay nada de nada------------
        public ActionResult Profesor_mensajeria()
        {
            return View();
        }
        public ActionResult Profesor_Perfil()
        {
            return View();
        }
        public ActionResult Profesor_Configuracion()
        {
            return View();
        }

        public ActionResult Profesor_Listar_CursosAsignados()
        {
            return View();
        }
        public ActionResult Profesor_Listar_Alumnos()
        {
            return View();
        }
        public ActionResult Profesor_Editar_Compcal()
        {
            return View();
        }
        public ActionResult Profesor_ReporteResultados()
        {
            return View();
        }
        public ActionResult Profesor_GraficoResultados()
        {
            return View();
        }

        [NonAction]
        public SelectList ToSelectList(DataTable table, string valueField, string textField)
        {
            List<SelectListItem> list = new List<SelectListItem>();

            foreach (DataRow row in table.Rows)
            {
                list.Add(new SelectListItem()
                {
                    Text = row[textField].ToString(),
                    Value = row[valueField].ToString()
                });
            }

            return new SelectList(list, "Value", "Text");
        }

    }
}
